Didi Birthday — Premium Pink Experience

This version keeps the original birthday flow and adds an interactive final experience:
- pink/blush/red/white visual system
- mixed typography hierarchy
- memory timeline
- interactive letter envelope
- three mystery gifts
- interactive birthday cake and candle reveal
- heart/confetti-style final reveal
- responsive mobile layout
- reduced-motion support

The project is static and can be opened from index.html or hosted directly on Netlify/GitHub Pages.
