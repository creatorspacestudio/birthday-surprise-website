"use strict";


/* =========================================================
   DIDI BIRTHDAY WEBSITE
   CLEAN MASTER SCRIPT
========================================================= */

const CONFIG = {

    loadingTime: 10,

    audioVolume: 0.75,

    transitionTime: 550,

    paths: {
        audio: "audio/",
        images: "images/",
        memes: "memes/"
    }

};


/* =========================================================
   BASE PATH
========================================================= */

function getBasePath() {

    if (
        window.location.pathname.includes("/pages/")
    ) {
        return "../";
    }

    return "./";
}


const BASE = getBasePath();


/* =========================================================
   AUDIO MANAGER
========================================================= */

const AudioManager = {

    current: [],


    create(file, loop = false, volume = CONFIG.audioVolume) {

        const audio = new Audio(
            BASE + CONFIG.paths.audio + file
        );

        audio.loop = loop;
        audio.volume = volume;
        audio.preload = "auto";

        this.current.push(audio);

        return audio;
    },


    play(
        file,
        loop = false,
        volume = CONFIG.audioVolume
    ) {

        const audio = this.create(
            file,
            loop,
            volume
        );

        const promise = audio.play();

        if (promise) {

            promise.catch(() => {

                console.log(
                    "Audio waiting for user interaction:",
                    file
                );

                window.__blockedAudio = audio;

            });

        }

        return audio;
    },


    stop(audio) {

        if (!audio) return;

        try {

            audio.pause();

            audio.currentTime = 0;

        } catch (e) {}

    },


    stopAll() {

        this.current.forEach(audio => {

            try {

                audio.pause();
                audio.currentTime = 0;

            } catch (e) {}

        });

        this.current = [];

    }

};


/* =========================================================
   AUDIO UNLOCK
========================================================= */

document.addEventListener(
    "pointerdown",
    () => {

        if (
            window.__blockedAudio
        ) {

            window.__blockedAudio
                .play()
                .catch(() => {});

            window.__blockedAudio = null;

        }

    },
    {
        once: true
    }
);


/* =========================================================
   CLICK SOUND
========================================================= */

function playClickSound() {

    try {

        const audio = new Audio(
            BASE +
            CONFIG.paths.audio +
            "click.mp3"
        );

        audio.volume = 0.35;

        audio.play().catch(() => {});

    } catch (e) {}

}


/* =========================================================
   PAGE TRANSITION
========================================================= */

function goToPage(url) {

    playClickSound();

    const transition =
        document.querySelector(
            ".page-transition"
        );

    if (transition) {

        transition.classList.add(
            "active"
        );

    }

    setTimeout(() => {

        window.location.href = url;

    }, CONFIG.transitionTime);

}


/* =========================================================
   STARS
========================================================= */

function createStars() {

    const field =
        document.getElementById(
            "starField"
        );

    if (!field) return;

    if (field.children.length > 0) {
        return;
    }


    for (
        let i = 0;
        i < 45;
        i++
    ) {

        const star =
            document.createElement("span");

        star.className = "star";

        star.style.left =
            Math.random() * 100 + "%";

        star.style.top =
            Math.random() * 100 + "%";

        star.style.animationDelay =
            Math.random() * 4 + "s";

        field.appendChild(star);

    }

}


/* =========================================================
   PARTICLES
========================================================= */

function createParticles() {

    const layer =
        document.getElementById(
            "particleLayer"
        );

    if (!layer) return;

    if (layer.children.length > 0) {
        return;
    }


    for (
        let i = 0;
        i < 18;
        i++
    ) {

        const particle =
            document.createElement("span");

        particle.className =
            "floating-sparkle";

        particle.style.left =
            Math.random() * 100 + "%";

        particle.style.top =
            Math.random() * 100 + "%";

        particle.style.animationDelay =
            Math.random() * 5 + "s";

        layer.appendChild(
            particle
        );

    }

}


/* =========================================================
   BUTTON RIPPLE
========================================================= */

function initButtonRipples() {

    document
        .querySelectorAll(
            "button"
        )
        .forEach(button => {

            button.addEventListener(
                "click",
                function (event) {

                    const ripple =
                        document.createElement(
                            "span"
                        );

                    ripple.className =
                        "button-ripple";

                    const rect =
                        button.getBoundingClientRect();

                    ripple.style.left =
                        (
                            event.clientX -
                            rect.left
                        ) + "px";

                    ripple.style.top =
                        (
                            event.clientY -
                            rect.top
                        ) + "px";

                    button.appendChild(
                        ripple
                    );

                    setTimeout(() => {

                        ripple.remove();

                    }, 700);

                }
            );

        });

}


/* =========================================================
   INDEX / LOADING
========================================================= */

function initLoadingScreen() {

    const screen =
        document.getElementById(
            "loadingScreen"
        );

    if (!screen) return;


    const timer =
        document.getElementById(
            "loadingTimer"
        );

    const progress =
        document.getElementById(
            "loadingProgress"
        );

    const status =
        document.getElementById(
            "loadingStatus"
        );

    const tip =
        document.getElementById(
            "loadingTip"
        );


    let seconds =
        CONFIG.loadingTime;


    /* -----------------------------------------
       LOADING AUDIO
    ----------------------------------------- */

    let loadingAudio = null;

    try {

        loadingAudio =
            new Audio(
                BASE +
                CONFIG.paths.audio +
                "loading.mp3"
            );

        loadingAudio.loop = true;
        loadingAudio.volume = 0.55;
        loadingAudio.preload = "auto";

        loadingAudio
            .play()
            .catch(() => {

                window.__blockedAudio =
                    loadingAudio;

            });

    } catch (e) {}


    /* -----------------------------------------
       INITIAL UI
    ----------------------------------------- */

    if (timer) {
        timer.textContent = seconds;
    }

    if (progress) {
        progress.style.width = "0%";
    }


    /* -----------------------------------------
       COUNTDOWN
    ----------------------------------------- */

    const interval =
        setInterval(() => {

            seconds--;

            if (timer) {

                timer.textContent =
                    Math.max(
                        seconds,
                        0
                    );

            }


            const percent =
                (
                    (
                        CONFIG.loadingTime -
                        seconds
                    ) /
                    CONFIG.loadingTime
                ) * 100;


            if (progress) {

                progress.style.width =
                    Math.min(
                        percent,
                        100
                    ) + "%";

            }


            if (status) {

                if (seconds > 7) {

                    status.textContent =
                        "Something special is loading...";

                } else if (seconds > 4) {

                    status.textContent =
                        "Preparing your surprise...";

                } else if (seconds > 1) {

                    status.textContent =
                        "Almost ready... 👀";

                } else {

                    status.textContent =
                        "Here we go... ❤️";

                }

            }


            if (tip) {

                const tips = [
                    "Please wait, Pyaari Didi... 💜",
                    "Thoda patience rakho 😭",
                    "Something cute is coming...",
                    "Don't leave now 👀",
                    "Almost there ❤️"
                ];

                const index =
                    Math.max(
                        0,
                        Math.min(
                            tips.length - 1,
                            Math.floor(
                                (
                                    CONFIG.loadingTime -
                                    seconds
                                ) / 2
                            )
                        )
                    );

                tip.textContent =
                    tips[index];

            }


            if (seconds <= 0) {

                clearInterval(
                    interval
                );


                if (loadingAudio) {

                    loadingAudio.pause();

                    loadingAudio.currentTime = 0;

                }


                screen.classList.add(
                    "hidden"
                );


                setTimeout(() => {

                    window.location.href =
                        "pages/surprise1.html";

                }, 650);

            }

        }, 1000);

}
/* =========================================================
   INDEX START BUTTON
========================================================= */

function initStartButton() {

    const button =
        document.getElementById(
            "startSurprise"
        );

    if (!button) return;


    button.addEventListener(
        "click",
        () => {

            goToPage(
                "pages/surprise1.html"
            );

        }
    );

}


/* =========================================================
   NAVIGATION BUTTONS
========================================================= */

function initNavigationButtons() {

    document
        .querySelectorAll(
            "[data-go]"
        )
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const target =
                        button.dataset.go;

                    if (!target) return;

                    goToPage(target);

                }
            );

        });

}


/* =========================================================
   SURPRISE 1
========================================================= */

const ANSWERS = {

    1: {

        sound: "funny-01.mp3",

        meme: "answer-nothing.png",

        next: "answer1.html"

    },


    2: {

        sound: "funny-02.mp3",

        meme: "answer-pata-nahi.png",

        next: "answer2.html"

    },


    3: {

        sound: "funny-03.mp3",

        meme: "answer-gift.png",

        next: "answer3.html"

    }

};


/* =========================================================
   ANSWER BUTTONS
========================================================= */

function initAnswerSelection() {

    document
        .querySelectorAll(
            ".answer-btn"
        )
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const answer =
                        button.dataset.answer;

                    const data =
                        ANSWERS[answer];

                    if (!data) return;


                    try {

                        sessionStorage.setItem(
                            "didiAnswer",
                            answer
                        );

                    } catch (e) {}


                    goToPage(
                        data.next
                    );

                }
            );

        });

}


/* =========================================================
   ANSWER PAGE
========================================================= */

function initAnswerPage() {

    const body =
        document.body;

    if (
        !body.classList.contains(
            "answer-page"
        )
    ) {
        return;
    }


    let answer = "1";

    try {

        answer =
            sessionStorage.getItem(
                "didiAnswer"
            ) || "1";

    } catch (e) {}


    const data =
        ANSWERS[answer] ||
        ANSWERS[1];


    /* -----------------------------------------
       MEME
    ----------------------------------------- */

    const meme =
        document.getElementById(
            "answerMeme"
        );

    if (meme) {

        meme.src =
            BASE +
            CONFIG.paths.memes +
            data.meme;

    }


    /* -----------------------------------------
       SOUND
    ----------------------------------------- */

    AudioManager.stopAll();

    AudioManager.play(
        data.sound,
        false,
        0.8
    );


    /* -----------------------------------------
       NEXT BUTTON
    ----------------------------------------- */

    const next =
        document.querySelector(
            "[data-answer-next]"
        );


    if (next) {

        next.addEventListener(
            "click",
            () => {

                AudioManager.stopAll();

                goToPage(
                    "surprise2.html"
                );

            }
        );

    }

}


/* =========================================================
   SURPRISE 2
========================================================= */

function initFakeEnding() {

    const button =
        document.getElementById(
            "finishFake"
        );

    if (!button) return;


    AudioManager.stopAll();


    AudioManager.play(
        "fake-ending.mp3",
        false,
        0.8
    );


    button.addEventListener(
        "click",
        () => {

            AudioManager.stopAll();


            document.body.classList.add(
                "screen-shake"
            );


            setTimeout(() => {

                goToPage(
                    "birthday.html"
                );

            }, 500);

        }
    );

}


/* =========================================================
   BIRTHDAY PAGE
========================================================= */

function initBirthdayPage() {

    if (
        !document.body.classList.contains(
            "birthday-page"
        )
    ) {
        return;
    }


    AudioManager.stopAll();


    AudioManager.play(
        "actual-surprise.mp3",
        true,
        0.8
    );


    createBirthdayHearts();

}


/* =========================================================
   BIRTHDAY HEARTS
========================================================= */

function createBirthdayHearts() {

    const container =
        document.body;

    for (
        let i = 0;
        i < 14;
        i++
    ) {

        const heart =
            document.createElement(
                "div"
            );

        heart.className =
            "floating-heart";

        heart.textContent =
            Math.random() > 0.5
                ? "❤️"
                : "💖";

        heart.style.left =
            Math.random() * 100 + "%";

        heart.style.animationDelay =
            Math.random() * 5 + "s";

        heart.style.animationDuration =
            6 +
            Math.random() * 5 +
            "s";

        container.appendChild(
            heart
        );

    }

}


/* =========================================================
   FINAL PAGE
   VIDEO VERSION
========================================================= */

function initFinalVideoPage() {

    if (
        !document.body.classList.contains(
            "final-page"
        )
    ) {
        return;
    }


    /* -----------------------------------------
       ABSOLUTELY STOP ALL WEBSITE AUDIO
    ----------------------------------------- */

    AudioManager.stopAll();


    const video =
        document.getElementById(
            "finalSlideshowVideo"
        );


    if (!video) {

        console.error(
            "Final slideshow video missing."
        );

        return;

    }


    const loading =
        document.getElementById(
            "videoLoading"
        );


    const soundButton =
        document.getElementById(
            "videoSoundButton"
        );


    /* -----------------------------------------
       VIDEO SETTINGS
    ----------------------------------------- */

    video.muted = true;

    video.volume = 1;

    video.playsInline = true;

    video.setAttribute(
        "playsinline",
        ""
    );

    video.setAttribute(
        "webkit-playsinline",
        ""
    );


    /* -----------------------------------------
       VIDEO READY
    ----------------------------------------- */

    video.addEventListener(
        "canplay",
        () => {

            if (loading) {

                loading.style.display =
                    "none";

            }

            video
                .play()
                .catch(() => {

                    console.log(
                        "Video waiting for interaction."
                    );

                });

        }
    );


    /* -----------------------------------------
       VIDEO ERROR
    ----------------------------------------- */

    video.addEventListener(
        "error",
        () => {

            console.error(
                "FINAL VIDEO ERROR:",
                video.error
            );


            if (loading) {

                loading.innerHTML =
                    "Video load nahi hua 😭";

            }

        }
    );


    /* -----------------------------------------
       SOUND BUTTON
    ----------------------------------------- */

    if (soundButton) {

        soundButton.addEventListener(
            "click",
            () => {

                video.muted = false;

                video.volume = 1;

                video
                    .play()
                    .then(() => {

                        soundButton.textContent =
                            "🔊 Music ON ❤️";

                    })
                    .catch(() => {

                        soundButton.textContent =
                            "🔊 Tap again";

                    });

            }
        );

    }


    /* -----------------------------------------
       FIRST TOUCH = VIDEO PLAY
    ----------------------------------------- */

    const unlockVideo =
        () => {

            if (
                video.muted
            ) {

                video
                    .play()
                    .catch(() => {});

            }

        };


    document.addEventListener(
        "pointerdown",
        unlockVideo,
        {
            once: true
        }
    );


    /* -----------------------------------------
       VIDEO FINISHED
    ----------------------------------------- */

    video.addEventListener(
        "ended",
        () => {

            const message =
                document.getElementById(
                    "finalMessage"
                );

            if (message) {

                message.innerHTML =
                    "Tum abhi bhi yaha ho didi? 😭❤️";

            }

        }
    );

}


/* =========================================================
   DO NOT CLICK
========================================================= */

function initDontClick() {

    const button =
        document.getElementById(
            "dontClick"
        );


    if (!button) return;


    button.addEventListener(
        "click",
        () => {

            AudioManager.stopAll();


            document.body.classList.add(
                "screen-shake"
            );


            setTimeout(() => {

                goToPage(
                    "surprise4.html"
                );

            }, 450);

        }
    );

}

/* =========================================================
   SECRET SURPRISE 4
========================================================= */

function initSecretPage() {

    if (
        !document.body.classList.contains(
            "secret-page"
        )
    ) {
        return;
    }


    /* -----------------------------------------
       STOP ALL PREVIOUS AUDIO
    ----------------------------------------- */

    AudioManager.stopAll();


    const gift =
        document.getElementById(
            "secretGift"
        );


    const photo =
        document.getElementById(
            "secretPhoto"
        );


    const reveal =
        document.getElementById(
            "secretReveal"
        );


    const giftText =
        document.getElementById(
            "giftText"
        );


    const wow =
        document.getElementById(
            "wowText"
        );


    const message =
        document.getElementById(
            "secretMessage"
        );


    if (!gift || !photo) {

        console.error(
            "Secret gift/photo missing."
        );

        return;

    }


    /* -----------------------------------------
       INITIAL STATE
    ----------------------------------------- */

    if (reveal) {

        reveal.classList.remove(
            "revealed"
        );

    }


    photo.classList.remove(
        "revealed"
    );


    if (wow) {

        wow.style.opacity = "0";

    }


    /* -----------------------------------------
       GIFT CLICK
    ----------------------------------------- */

    gift.addEventListener(
        "click",
        () => {

            playClickSound();


            /* GIFT ANIMATION */

            gift.classList.add(
                "gift-open"
            );


            if (giftText) {

                giftText.textContent =
                    "Wait for it... 👀❤️";

            }


            /* ---------------------------------
               REVEAL PHOTO
            --------------------------------- */

            setTimeout(() => {

                if (reveal) {

                    reveal.classList.add(
                        "revealed"
                    );

                }


                photo.classList.add(
                    "revealed"
                );


                document.body.classList.add(
                    "screen-shake"
                );


                createSecretSparks();


            }, 700);


            /* ---------------------------------
               WOW + SOUND
            --------------------------------- */

            setTimeout(() => {

                AudioManager.stopAll();


                AudioManager.play(
                    "fake-ending.mp3",
                    false,
                    0.8
                );


                if (wow) {

                    wow.style.opacity =
                        "1";

                    wow.classList.add(
                        "wow-active"
                    );

                }


                if (message) {

                    message.textContent =
                        "Maine bola tha DO NOT CLICK 😭😂❤️";

                }


            }, 3500);

        }
    );

}


/* =========================================================
   SECRET SPARKS
========================================================= */

function createSecretSparks() {

    for (
        let i = 0;
        i < 24;
        i++
    ) {

        const spark =
            document.createElement(
                "span"
            );

        spark.className =
            "floating-sparkle";

        spark.style.left =
            50 +
            (
                Math.random() * 40 -
                20
            ) +
            "%";

        spark.style.top =
            45 +
            (
                Math.random() * 30 -
                15
            ) +
            "%";

        spark.style.animationDelay =
            Math.random() * 0.5 +
            "s";

        document.body.appendChild(
            spark
        );


        setTimeout(() => {

            spark.remove();

        }, 2500);

    }

}

/* =========================================================
   PAGE TYPE
========================================================= */

function getPageType() {

    const path =
        window.location.pathname
            .toLowerCase();


    if (
        path.endsWith(
            "/index.html"
        ) ||
        !path.includes("/pages/")
    ) {

        return "index";

    }


    if (
        path.endsWith(
            "/surprise1.html"
        )
    ) {

        return "surprise1";

    }


    if (
        path.endsWith(
            "/answer1.html"
        )
    ) {

        return "answer1";

    }


    if (
        path.endsWith(
            "/answer2.html"
        )
    ) {

        return "answer2";

    }


    if (
        path.endsWith(
            "/answer3.html"
        )
    ) {

        return "answer3";

    }


    if (
        path.endsWith(
            "/surprise2.html"
        )
    ) {

        return "surprise2";

    }


    if (
        path.endsWith(
            "/birthday.html"
        )
    ) {

        return "birthday";

    }


    if (
        path.endsWith(
            "/final.html"
        )
    ) {

        return "final";

    }


    if (
        path.endsWith(
            "/surprise4.html"
        )
    ) {

        return "surprise4";

    }


    return "unknown";

}


/* =========================================================
   INITIALIZE
========================================================= */

function initializePage() {

    createStars();

    createParticles();

    initButtonRipples();

    initNavigationButtons();


    const type =
        getPageType();


    console.log(
        "DidiBirthday page:",
        type
    );


    switch (type) {


        case "index":

            initLoadingScreen();

            initStartButton();

            break;


        case "surprise1":

            initAnswerSelection();

            break;


        case "answer1":
        case "answer2":
        case "answer3":

            initAnswerPage();

            break;


        case "surprise2":

            initFakeEnding();

            break;


        case "birthday":

            initBirthdayPage();

            break;


        case "surprise4":

            initSecretPage();

            break;

    }

}


/* =========================================================
   DOM READY
========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializePage
    );

} else {

    initializePage();

}


/* =========================================================
   PAGE HIDE
========================================================= */

window.addEventListener(
    "pagehide",
    () => {

        AudioManager.stopAll();

    }
);


/* =========================================================
   PREVENT DOUBLE CLICK
========================================================= */

document.addEventListener(
    "dblclick",
    event => {

        event.preventDefault();

    }
);


/* =========================================================
   IMAGE DEBUG
========================================================= */

document.addEventListener(
    "error",
    event => {

        if (
            event.target &&
            event.target.tagName ===
            "IMG"
        ) {

            console.error(
                "IMAGE FAILED:",
                event.target.src
            );

        }

    },
    true
);


/* =========================================================
   FINAL VIDEO DEBUG
========================================================= */

window.addEventListener(
    "load",
    () => {

        const video =
            document.getElementById(
                "finalSlideshowVideo"
            );

        if (video) {

            console.log(
                "FINAL VIDEO:",
                video.currentSrc
            );

        }

    }
);